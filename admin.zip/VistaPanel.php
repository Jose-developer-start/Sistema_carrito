<?php
include("modulos/panel.php");  
include("cabecera.php");
include("sidebar.php");
?>

  <!-- Left side column. contains the logo and sidebar -->


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        INCIO
        <small>Resumen ventas</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="../index.php"><h4> Ir a Carrito</h4></a></li>
         <li><a href="#"><h3> </h3></a></li>

             </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php echo $totalVentas; ?></h3>

              <p>Ordenes concretadas</p>
            </div>
            <div class="icon">
              <i class="ion ion-bag"></i>
            </div>
            
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3><?php echo $totalVentasPendientes; ?><sup style="font-size: 20px"></sup></h3>

              <p>Órdenes pendiente</p>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3>$<?php echo number_format($IngresoTotalesVentas,2);; ?></h3>

              <p>Ingresos Totales</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3>No disponible</h3>

              <p>No disponible</p>
            </div>
            <div class="icon">
              <i class="ion ion-pie-graph"></i>
            </div>
          </div>
        </div>
        <!-- ./col -->
      </div>


      <!-- /.row -->

      <!-- Main row -->
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Resumen de las ventas</h3>

              <div class="box-tools">
                <div class="input-group input-group-sm" style="width: 150px;">
                  <input type="text" name="table_search" class="form-control pull-right" placeholder="Search">

                  <div class="input-group-btn">
                    <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                  </div>
                </div>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-hover">
                <tbody><tr>
                  <th>ID</th>
                  <th>Clave Transacción</th>
                  <th>Nombre</th>
                  <th>Fecha׀ Hora</th>
                  <th>Estado</th>
                  <th>Total a Pagar</th>
                  <th>Correo</th>
                  <th>Acción</th>
                </tr>
                <!--Mostramos la tabla ventas--->
                <?php foreach ($listaProd as $fila){?>
                <tr>
                  <td><?php echo $fila ['ID']; ?></td>
                  <td><?php echo $fila ['ClaveTransacion']; ?></td>
                  <td><?php echo $fila ['Nombre']; ?></td>
                  <td><?php echo $fila ['Fecha']; ?></td>
                  <!--Condicional para ver el estado de la compra-->
                  <td><?php if($fila['status']=='pendiente'){?><span class="label label-warning"><?php echo $fila['status']; ?></span><?php }else{?><span class="label label-success"><?php echo $fila ['status']; ?></span><?php }?>
                  </td>
                  <!--Condicional para ver el estado de la compra Fin-->
                  <td>$<?php echo $fila ['Total']; ?></td>
                  <td><?php echo $fila ['Correo']; ?></td>
                  <td><?php if($fila['status']=='Completo'){?><a href="print.php?id_usuario=<?php echo $fila ['ID']; ?>" class="btn btn-success">Factura</a> <?php }?></td>
                </tr>
                <?php }?>
                <!--Mostramos la tabla ventas Fin--->
              </tbody></table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>
      <!-- /.row (main row) -->

    </section>
    <!-- /.content -->
  </div>


<?php include("footer.php");?>
