<?php
include("modulos/agregarAdmin.php");  
include("cabecera.php");
include("sidebar.php");
?>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        ADMINISTRADOR
        <small>Agregar</small>
      </h1>
      <ol class="breadcrumb">
         <li><a href="../index.php"><h4> Ir a Carrito</h4></a></li>
         <li><a href="VistaPanel.php"><h4>inicio</h4></a></li>
        
        <li class="active">Agregar Administradores</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      


      <!-- /.row -->
      <!---Formulario de producto-->

          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Agregar administradores</h3>
            </div>
            <!-- /.box-header -->

            <!-- form start -->
            <form role="form" action="" method="post" enctype="multipart/form-data">
              <div class="one_third first">
              <!--<label for="codigo">codigo</label>-->
                <input type="hidden" name="ID" id="Nombres" placeholder="codigo">
              </div>
              <div class="box-body">
                <div class="form-group">
                  <label for="exampleInputEmail1">Nombre</label>
                  <input type="text" name="nombre" class="form-control" id="exampleInputEmail1" placeholder="Nombres del administrador" required="">
                </div>
                <div class="form-group">
                  <label for="exampleInputEmail1">Apellidos</label>
                  <input type="text" name="apellido" class="form-control" id="exampleInputEmail1" placeholder="Apellido Maternal y Paternal" required="">
                </div>
                <div class="form-group">
                  <label for="exampleInputEmail1">Correo</label>
                  <input type="email" name="correo" class="form-control" id="exampleInputEmail1" placeholder="Email personal" required="">
                </div>
                <div class="form-group">
                  <label for="exampleInputEmail1">Password</label>
                  <input type="password" name="password" class="form-control" id="exampleInputEmail1" placeholder="Ingrese contraseña segura" required="">
                </div>

                <div class="form-group">
                  <label for="exampleInputFile">Agregar Foto</label>
                  <input type="file" accept="image/*" name="txtFoto" id="exampleInputFile"required>
                </div>
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <button class="btn btn-primary" type="submit" name="accion" value="btnagregar">Agregar</button>
              </div>
            </form>
          </div>
          <!-- form end -->
          <!--Mostrar Productos-->
          <div class="col-xs-12">
            <div class="box">
              <div class="box-header">
                <h3 class="box-title">Administradores disponibles</h3>
                <div class="box-tools">
                  <div class="input-group input-group-sm" style="width: 150px;">
                    <input id="busqueda" type="text" name="table_search" class="form-control pull-right" placeholder="Buscar">
                  </div>
                </div>
              </div>
            <!-- /.box-header -->

            <div class="box-body table-responsive no-padding">
              <table class="table table-hover">
                <tbody class="busquedatabla"><tr>
                  <th>ID</th>
                  <th>Nombres</th>
                  <th>Apellidos</th>
                  <th>Correo</th>
                  <th>Contraseña</th>
                  <th>Foto</th>
                  <th class="text-center">Acción</th>
                </tr>
                <?php foreach ($listaProd as $fila){?>
                <tr>
                  <td><?php echo $fila ['ID']; ?></td>
                  <td><?php echo $fila ['Nombres']; ?></td>
                  <td><?php echo $fila ['Apellidos']; ?></td>
                  <td><?php echo $fila ['Correo']; ?></td>
                  <td><?php echo md5($fila['Password']); ?></td>
                  <td><img class ="img-thumbnail" width= "100px" src="./dist/imgadmin/<?php echo $fila ['Foto']; ?>" /></td>
                  <td>
                    <form action="" method="post">
                      <input type="hidden" name="ID" value="<?php echo $fila ['ID']; ?>">
                      <input type="hidden" name="nombre" value="<?php echo $fila ['Nombres']; ?>"> 
                      <input type="hidden" name="apellido" value="<?php echo $fila ['Apellidos']; ?>">
                      <input type="hidden" name="correo" value="<?php echo $fila ['Correo']; ?>"> 
                      <input type="hidden" name="password" value="<?php echo $fila ['Password']; ?>"> 
                      <input type="hidden" name="txtFoto" value="<?php echo $fila ['Foto']; ?>">
                       
                      <button class="btn btn-danger" type="submit" name="accion" value="btneliminar">Eliminar</button>
                    </form>
                  </td>
                </tr>
                <?php }?><!--Cerrando Bucle Foreach-->
              </tbody></table>
            </div>
            <!-- /.box-body -->
          </div>
          <!--Mostrar Productos Fin-->
          <!-- /.box -->
        </div>
        </div>
      </section>

<?php include("footer.php");?>