<?php
include("modulos/modPerfil.php");
include("cabecera.php");
include("sidebar.php");
?>
<div class="content-wrapper" style="min-height: 1126px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Perfil de administrador
      </h1>
      <ol class="breadcrumb">
        <li><a href="VistaPanel.php"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="active">Perfil admin</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-md-3">

          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-body box-profile">
              <img class="profile-user-img img-responsive img-circle" src="../assets/fotosAdmin/<?php echo $fotoAdmin;?>" alt="User profile picture">

              <h3 class="profile-username text-center"><?php echo $nombreAdmin;?></h3>

              <p class="text-muted text-center">Administrador</p>

              <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                  <b>Nombre: </b> <a class="pull-right"><?php echo $nombreAdmin;?></a>
                </li>
                <li class="list-group-item">
                  <b>Apellidos: </b> <a class="pull-right"><?php echo $apellidoAdmin;?></a>
                </li>
                <li class="list-group-item">
                  <b>Correo: </b> <a class="pull-right"><?php echo $emailAdmin;?></a>
                </li>
              </ul>

              <a href="CerrarSession.php" class="btn btn-primary btn-block"><b>Cerrar Sesión</b></a>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
        <div class="col-md-9">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#settings" data-toggle="tab">Actualizar Perfil</a></li>
              <!--<li><a href="#timeline" data-toggle="tab">Agregar Admin</a></li>-->
            </ul>
            <!--Formulario para actualizar perfil-->
            <div class="tab-content">
              <div class="active tab-pane" id="activity">

              <div class="tab-pane" id="settings">
                <form action="" class="form-horizontal" method="POST" enctype="multipart/form-data">
                  <div class="form-group">
                    <!--<label for="inputName" class="col-sm-2 control-label">ID</label>-->

                    <div class="col-sm-10">
                      <input type="hidden" name="ID" class="form-control" id="inputName" placeholder="Id" value="<?php echo $idSession;?>">
                    </div>
                  </div>

                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Nombres</label>

                    <div class="col-sm-10">
                      <input type="text" name="nombres" class="form-control" id="inputName" placeholder="Nombres" value="<?php echo $nombreAdmin;?>" required>
                    </div>
                  </div>

                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Apellidos</label>

                    <div class="col-sm-10">
                      <input type="text" name="apellidos" class="form-control" id="inputName" placeholder="Apellidos" value="<?php echo $apellidoAdmin;?>" required>
                    </div>
                  </div>

                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Correo</label>

                    <div class="col-sm-10">
                      <input type="email" name="correo" class="form-control" id="inputName" placeholder="Correo personal" value="<?php echo $emailAdmin;?>" required>
                    </div>
                  </div>

                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Contraseña</label>

                    <div class="col-sm-10">
                      <input type="password" name="password" class="form-control" id="inputName" placeholder="Ingresar la contraseña" value="<?php echo $passwordAdmin;?>" required>
                    </div>
                  </div>

                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Agregar Foto</label>

                    <div class="col-sm-10">
                      <input type="file" accept="image/*" name="txtFoto" id="exampleInputFile" value="<?php echo $imgAdmin;?>">
                    </div>
                  </div>
                  
                  <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                      <button type="submit" name="accion" class="btn btn-primary" value="btnmodificar">Actualizar</button>
                    </div>
                  </div>
                </form>
              </div>
              <!-- /.tab-pane -->
            </div>
            <!--Fin formulario-->
            <!-- /.tab-content -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->
</div>

<?php include("footer.php");?>