<?php
include("modulos/ventas.php"); 
include("cabecera.php");
include("sidebar.php");

?>

  <!-- Left side column. contains the logo and sidebar -->


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        VENTAS ׀ TECHNOLOGY BOX
        <small>Panel de Ventas</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="../index.php"><h4> Ir a Carrito</h4></a></li>
         <li><a href="VistaPanel.php"><h4>inicio</h4></a></li>
        <li class="active">SISTEMA ׀ TECHNOLOGY BOX</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
   
      <!-- Main row -->
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">TABLA DE VENTAS</h3>
              <a class="btn btn-success" href="informe.php" style="height: 30px;">Informe</a>
              <div class="box-tools">
                <div class="input-group input-group-sm" style="width: 150px;">
                  <input id="busqueda" type="text" name="table_search" class="form-control pull-right" placeholder="Buscar">
                </div>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-hover">
                <tbody class="busquedatabla"><tr>
                  <th>ID</th>
                  <th>Nombre</th>
                  <th>Producto</th>
                  <th>Fecha ׀ Hora</th>
                  <th>Correo</th>
                </tr>
                <?php
                foreach($ventas as $row){?>

                <tr>
                  <td><?php echo $row["IDVENTA"]?></td>
                  <td><?php echo $row["Nombre"]?></td>
                  <td>
                    <?php
                      foreach($product as $row1){
                        $id = $row1['CodigoProd'];
                        $nombre_prod = $row1['NombreProd'];
                        if($id==$row['IDPRODUCTO']){
                        echo $nombre_prod;
                      }
                    } ?>
                      
                  </td>
                  <td><?php echo $row["Fecha"]?></td>
                  <td><?php echo $row["Correo"]?> </td>
                </tr>
              <?php
               }
                ?>
              </tbody></table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>
      <!-- /.row (main row) -->

    </section>
    <!-- /.content -->
  </div>

<?php include("footer.php");?>