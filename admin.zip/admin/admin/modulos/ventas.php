<?php
include(".././global/sessiones.php");
include(".././global/db.php");


$sentencia_query_prod = $pdo->prepare("SELECT * FROM productos");
$sentencia_query_prod->execute();
$product = $sentencia_query_prod->fetchall();

$sentencia_query = $pdo->prepare("SELECT * FROM ventas INNER JOIN detalleventa ON ventas.ID=detalleventa.IDVENTA WHERE status='Completo'");
$sentencia_query->execute();
$ventas = $sentencia_query->fetchall();


?>